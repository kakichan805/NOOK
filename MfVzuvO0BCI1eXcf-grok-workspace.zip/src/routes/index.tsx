import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Clock } from "@/nook/clock";
import { Welcome } from "@/nook/welcome";
import { Room } from "@/nook/room";
import { normalizeRoom, readBoot, rememberJoin, rememberLeave, type Boot } from "@/nook/model";

export const Route = createFileRoute("/")({
  validateSearch: (search: Record<string, unknown>): { room?: string } => {
    const raw = typeof search.room === "string" ? search.room : "";
    const room = normalizeRoom(raw);
    return room ? { room } : {};
  },
  component: Home,
});

function Home() {
  const search = Route.useSearch();
  const navigate = Route.useNavigate();
  const room = search.room ?? "";
  const [boot, setBoot] = useState<Boot | null>(null);

  useEffect(() => {
    setBoot(readBoot(room));
  }, [room]);

  if (!boot) {
    return (
      <div className="mx-auto flex h-dvh w-full max-w-md flex-col bg-lane px-4 pt-4">
        <Clock />
        <p className="font-pixel mt-8 text-4xl text-paper">Nook</p>
      </div>
    );
  }

  if (!boot.joined) {
    return (
      <Welcome
        invitedRoom={room}
        savedName={boot.name}
        onJoin={(name, room) => {
          const next: Boot = {
            joined: true,
            name,
            room,
            zone: "study",
            since: Date.now(),
            selfId: boot.selfId,
          };
          rememberJoin(next);
          setBoot(next);
          void navigate({ to: "/", search: { room }, replace: true });
        }}
      />
    );
  }

  return (
    <Room
      key={`${boot.room}:${boot.selfId}`}
      room={boot.room}
      name={boot.name}
      selfId={boot.selfId}
      initialZone={boot.zone}
      initialSince={boot.since}
      onLeave={() => {
        rememberLeave();
        setBoot(readBoot(room || boot.room));
      }}
    />
  );
}
