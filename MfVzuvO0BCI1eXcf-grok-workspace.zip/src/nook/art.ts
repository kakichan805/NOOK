import study from "@/assets/nook/study.jpg";
import snack from "@/assets/nook/snack.jpg";
import rest from "@/assets/nook/rest.jpg";
import wash from "@/assets/nook/wash.jpg";
import door from "@/assets/nook/door.jpg";
import look0 from "@/assets/nook/look-0.png";
import look1 from "@/assets/nook/look-1.png";
import look2 from "@/assets/nook/look-2.png";
import look3 from "@/assets/nook/look-3.png";
import sit0 from "@/assets/nook/sit-0.png";
import type { Zone } from "./model";

export const ROOM_ART: Record<Zone, string> = { study, snack, rest, wash, door };

export const ROOM_ALT: Record<Zone, string> = {
  study: "A cozy study with two wooden desks and warm lamps",
  snack: "A small snack table with tea, fruit, and cookies",
  rest: "A low bed with soft linen and a bedside lamp",
  wash: "A bright washroom with a round mirror and sink",
  door: "The front door, slightly open",
};

const STANDING = [look0, look1, look2, look3];
const STUDYING = [sit0, look1, look2, look3];

export function spriteFor(look: number, zone: Zone): string {
  const index = ((Math.floor(look) % 4) + 4) % 4;
  if (zone === "study") return STUDYING[index];
  return STANDING[index];
}
