export const ZONES = [
  { id: "study", label: "Study", doing: "Studying" },
  { id: "snack", label: "Snack", doing: "At the table" },
  { id: "rest", label: "Rest", doing: "Resting" },
  { id: "wash", label: "Wash", doing: "Washroom" },
  { id: "door", label: "Door", doing: "By the door" },
] as const;

export type Zone = (typeof ZONES)[number]["id"];

export interface Presence {
  name: string;
  zone: Zone;
  since: number;
  look: number;
}

const ROOM_RE = /^[a-z0-9_-]{1,64}$/;

const ADJECTIVES = ["maple", "linen", "amber", "moss", "cocoa", "cedar", "honey", "plum", "willow", "ivory"];
const NOUNS = ["lamp", "desk", "mug", "quilt", "nook", "kettle", "page", "moon"];

export function isZone(value: unknown): value is Zone {
  return ZONES.some((zone) => zone.id === value);
}

export function zoneMeta(zone: Zone) {
  return ZONES.find((item) => item.id === zone) ?? ZONES[0];
}

export function makeRoom(): string {
  const adjective = ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)];
  const noun = NOUNS[Math.floor(Math.random() * NOUNS.length)];
  const suffix = Math.random().toString(36).slice(2, 5);
  return `${adjective}-${noun}-${suffix}`;
}

export function cleanName(raw: string): string {
  return raw.replace(/\s+/g, " ").trim().slice(0, 16);
}

export function normalizeRoom(raw: string): string | null {
  const code = raw.trim().toLowerCase();
  if (!ROOM_RE.test(code)) return null;
  return code;
}

export function lookFor(name: string): number {
  let hash = 0;
  for (const char of name) hash = (hash * 31 + char.charCodeAt(0)) >>> 0;
  return hash % 4;
}

export function formatStay(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const seconds = total % 60;
  const pad = (value: number) => value.toString().padStart(2, "0");
  if (hours > 0) return `${hours}:${pad(minutes)}:${pad(seconds)}`;
  return `${minutes}:${pad(seconds)}`;
}

export function isPresence(data: unknown): data is Presence {
  if (!data || typeof data !== "object") return false;
  const row = data as Record<string, unknown>;
  return (
    typeof row.name === "string" &&
    row.name.length > 0 &&
    row.name.length <= 16 &&
    isZone(row.zone) &&
    typeof row.since === "number" &&
    Number.isFinite(row.since) &&
    typeof row.look === "number" &&
    Number.isFinite(row.look)
  );
}

const KEY = {
  name: "nook-name",
  active: "nook-active",
  room: "nook-room",
  zone: "nook-zone",
  since: "nook-since",
  self: "nook-self",
} as const;

export interface Boot {
  joined: boolean;
  name: string;
  room: string;
  zone: Zone;
  since: number;
  selfId: string;
}

function selfId(): string {
  const existing = sessionStorage.getItem(KEY.self);
  if (existing && /^[a-zA-Z0-9_-]{1,64}$/.test(existing)) return existing;
  const next = `p-${Math.random().toString(36).slice(2, 10)}`;
  sessionStorage.setItem(KEY.self, next);
  return next;
}

export function readBoot(roomFromUrl: string): Boot {
  const name = sessionStorage.getItem(KEY.name) ?? "";
  const active = sessionStorage.getItem(KEY.active) === "1";
  const storedRoom = sessionStorage.getItem(KEY.room) ?? "";
  const storedZone = sessionStorage.getItem(KEY.zone);
  const storedSince = Number(sessionStorage.getItem(KEY.since));
  const sameRoom = Boolean(roomFromUrl) && roomFromUrl === storedRoom;
  const zone = sameRoom && isZone(storedZone) ? storedZone : "study";
  const since = sameRoom && Number.isFinite(storedSince) && storedSince > 0 ? storedSince : Date.now();
  return {
    joined: active && name.length > 0 && sameRoom,
    name,
    room: roomFromUrl,
    zone,
    since,
    selfId: selfId(),
  };
}

export function rememberJoin(boot: Boot) {
  sessionStorage.setItem(KEY.name, boot.name);
  sessionStorage.setItem(KEY.active, "1");
  sessionStorage.setItem(KEY.room, boot.room);
  sessionStorage.setItem(KEY.zone, boot.zone);
  sessionStorage.setItem(KEY.since, String(boot.since));
}

export function rememberSpot(zone: Zone, since: number) {
  sessionStorage.setItem(KEY.zone, zone);
  sessionStorage.setItem(KEY.since, String(since));
}

export function rememberLeave() {
  sessionStorage.setItem(KEY.active, "0");
  sessionStorage.removeItem(KEY.zone);
  sessionStorage.removeItem(KEY.since);
}
