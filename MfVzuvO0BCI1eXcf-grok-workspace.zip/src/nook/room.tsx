import { useEffect, useMemo, useRef, useState } from "react";
import { BookOpen, Coffee, DoorOpen, Droplets, Moon, Share2 } from "lucide-react";
import { useP2PRoom } from "@/lib/multiplayer/use-p2p-room";
import { AppHeader } from "./clock";
import { ROOM_ALT, ROOM_ART, spriteFor } from "./art";
import {
  ZONES,
  formatStay,
  isPresence,
  rememberSpot,
  zoneMeta,
  type Presence,
  type Zone,
} from "./model";

const ICONS = {
  study: BookOpen,
  snack: Coffee,
  rest: Moon,
  wash: Droplets,
  door: DoorOpen,
} as const;

interface RoomProps {
  room: string;
  name: string;
  selfId: string;
  initialZone: Zone;
  initialSince: number;
  onLeave: () => void;
}

interface Remote extends Presence {
  seen: number;
}

export function Room({ room, name, selfId, initialZone, initialSince, onLeave }: RoomProps) {
  const p2p = useP2PRoom({ room, name, selfId });
  const [zone, setZone] = useState<Zone>(initialZone);
  const [since, setSince] = useState(initialSince);
  const [now, setNow] = useState(() => Date.now());
  const [others, setOthers] = useState<Record<string, Remote>>({});
  const [note, setNote] = useState("");
  const [slow, setSlow] = useState(false);
  const look = useMemo(() => {
    let hash = 0;
    for (const char of name) hash = (hash * 31 + char.charCodeAt(0)) >>> 0;
    return hash % 4;
  }, [name]);
  const presence = useMemo<Presence>(() => ({ name, zone, since, look }), [name, zone, since, look]);
  const presenceRef = useRef(presence);
  presenceRef.current = presence;
  const greeted = useRef(new Set<string>());

  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    const id = window.setTimeout(() => setSlow(true), 6000);
    return () => window.clearTimeout(id);
  }, []);

  useEffect(() => p2p.onMessage((from, data) => {
    if (!isPresence(data)) return;
    setOthers((current) => ({ ...current, [from]: { ...data, name: data.name.slice(0, 16), seen: Date.now() } }));
  }), [p2p.onMessage]);

  useEffect(() => {
    p2p.broadcast(presence);
    const id = window.setInterval(() => p2p.broadcast(presenceRef.current), 2000);
    return () => window.clearInterval(id);
  }, [presence, p2p.broadcast]);

  useEffect(() => {
    for (const peer of p2p.peers) {
      if (peer.connectionState === "connected" && !greeted.current.has(peer.id)) {
        greeted.current.add(peer.id);
        p2p.send(presenceRef.current, peer.id);
      }
    }
    const ids = new Set(p2p.peers.map((peer) => peer.id));
    setOthers((current) => {
      let changed = false;
      const next = { ...current };
      for (const id of Object.keys(next)) {
        if (!ids.has(id)) {
          delete next[id];
          greeted.current.delete(id);
          changed = true;
        }
      }
      return changed ? next : current;
    });
  }, [p2p.peers, p2p.send]);

  useEffect(() => {
    const id = window.setInterval(() => {
      const cutoff = Date.now() - 10000;
      setOthers((current) => {
        let changed = false;
        const next = { ...current };
        for (const [id, person] of Object.entries(next)) {
          if (person.seen < cutoff) {
            delete next[id];
            changed = true;
          }
        }
        return changed ? next : current;
      });
    }, 2000);
    return () => window.clearInterval(id);
  }, []);

  function move(next: Zone) {
    if (next === zone) return;
    const at = Date.now();
    setZone(next);
    setSince(at);
    rememberSpot(next, at);
  }

  function leave() {
    p2p.close();
    onLeave();
  }

  async function share() {
    const url = new URL(window.location.href);
    url.searchParams.set("room", room);
    const shareUrl = url.toString();
    try {
      if (navigator.share) {
        await navigator.share({ title: "Nook", text: "Come study in my nook.", url: shareUrl });
        return;
      }
    } catch {
      return;
    }
    try {
      await navigator.clipboard.writeText(shareUrl);
      setNote("Link copied");
      window.setTimeout(() => setNote(""), 2000);
    } catch {
      setNote(shareUrl);
    }
  }

  const here = Object.entries(others)
    .filter(([, person]) => person.zone === zone)
    .map(([id, person]) => ({ id, ...person }));
  const people = [...here];
  people.splice(Math.floor(people.length / 2), 0, { id: "self", name, zone, since, look, seen: now });

  const counts = Object.fromEntries(ZONES.map((item) => [item.id, item.id === zone ? 1 : 0])) as Record<Zone, number>;
  for (const person of Object.values(others)) counts[person.zone] += 1;

  const failed = p2p.peers.filter((peer) => peer.connectionState === "failed").length;
  const doing = zoneMeta(zone).doing;

  return (
    <div className="mx-auto flex h-dvh w-full max-w-md flex-col bg-lane">
      <AppHeader>
        <button
          type="button"
          onClick={() => void share()}
          className="flex h-11 items-center gap-2 rounded-xl bg-ink px-3 text-paper focus-visible:ring-2 focus-visible:ring-lamp"
        >
          <Share2 className="size-4" aria-hidden="true" />
          <span className="font-pixel text-xs">{note || "Share"}</span>
        </button>
      </AppHeader>

      <div className="flex items-end justify-between gap-3 px-4 pb-3">
        <div className="min-w-0">
          <p className="font-pixel text-sm leading-none text-paper">{doing}</p>
          <p className="mt-1 truncate font-sans text-sm text-muted">{room}</p>
        </div>
        <p className="font-pixel shrink-0 text-xs text-muted">
          {p2p.joined ? "In the room" : slow ? "Still connecting" : "Connecting"}
        </p>
      </div>

      <section className="relative min-h-0 flex-1 overflow-hidden" aria-label={doing}>
        <img
          key={zone}
          src={ROOM_ART[zone]}
          alt={ROOM_ALT[zone]}
          className="nook-fade absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-x-0 bottom-0 flex items-end justify-evenly gap-1 px-2 pb-3">
          {people.map((person) => {
            const mine = person.id === "self";
            const tall = people.length <= 1 ? "h-44" : people.length <= 3 ? "h-36" : "h-28";
            return (
              <figure key={person.id} className="flex w-16 flex-col items-center">
                <figcaption className="mb-1 flex max-w-full flex-col items-center gap-1">
                  <span
                    className={
                      "font-pixel max-w-full truncate rounded-md px-1.5 py-1 text-xs leading-none " +
                      (mine ? "bg-lamp text-ink" : "bg-paper text-ink")
                    }
                  >
                    {person.name}
                  </span>
                  <span className="font-pixel rounded-md bg-ink px-1.5 py-1 text-xs leading-none text-lamp">
                    {formatStay(now - person.since)}
                  </span>
                </figcaption>
                <img
                  src={spriteFor(person.look, zone)}
                  alt=""
                  className={`${tall} w-auto max-w-full object-contain ${zone === "study" || zone === "rest" ? "" : "nook-bob"}`}
                />
              </figure>
            );
          })}
        </div>
        {zone === "door" ? (
          <div className="absolute inset-x-4 top-4">
            <button
              type="button"
              onClick={leave}
              className="h-12 w-full rounded-xl bg-lamp text-base font-bold text-ink focus-visible:ring-2 focus-visible:ring-paper"
            >
              Step outside
            </button>
          </div>
        ) : null}
      </section>

      {failed > 0 ? (
        <p className="px-4 py-2 text-center text-sm text-muted">
          {failed === 1 ? "One person" : `${failed} people`} couldn't connect from their network.
        </p>
      ) : null}
      {!p2p.joined && slow ? (
        <p className="px-4 pb-2 text-center text-sm text-muted">You can still settle in. Friends appear when the link connects.</p>
      ) : null}
      {Object.keys(others).length === 0 && p2p.joined ? (
        <p className="px-4 py-2 text-center text-sm text-muted">Just you for now. Share the link to study together.</p>
      ) : null}

      <nav
        className="grid grid-cols-5 gap-1 bg-ink px-2 pt-2"
        style={{ paddingBottom: "max(0.75rem, env(safe-area-inset-bottom))" }}
        aria-label="Places in the room"
      >
        {ZONES.map((item) => {
          const Icon = ICONS[item.id];
          const active = item.id === zone;
          return (
            <button
              key={item.id}
              type="button"
              aria-pressed={active}
              onClick={() => move(item.id)}
              className={
                "flex min-h-14 flex-col items-center justify-center gap-1 rounded-xl px-1 " +
                (active ? "bg-lamp text-ink" : "text-paper")
              }
            >
              <Icon className="size-5" aria-hidden="true" />
              <span className="font-pixel text-xs leading-none">
                {item.label}
                <span className="sr-only">, {counts[item.id]} here</span>
              </span>
              <span className={"font-sans text-xs leading-none " + (active ? "text-ink" : "text-muted")}>
                {counts[item.id]}
              </span>
            </button>
          );
        })}
      </nav>
      <p className="sr-only" aria-live="polite">
        {name} has been {doing.toLowerCase()} for {formatStay(now - since)}.
      </p>
    </div>
  );
}
