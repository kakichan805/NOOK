import { useEffect, useState, type ReactNode } from "react";

export function Clock() {
  const [now, setNow] = useState<Date | null>(null);

  useEffect(() => {
    const tick = () => setNow(new Date());
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, []);

  const time = now
    ? now.toLocaleTimeString(undefined, {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false,
      })
    : "--:--:--";
  const day = now
    ? now.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" })
    : "Local time";

  return (
    <div className="min-w-0">
      <time
        dateTime={now ? now.toISOString() : undefined}
        aria-label={`Local time ${time}`}
        className="font-pixel block text-3xl leading-none tracking-wide text-lamp"
      >
        {time}
      </time>
      <p className="font-pixel mt-1 text-xs leading-none text-muted">{day}</p>
    </div>
  );
}

export function AppHeader({ children }: { children?: ReactNode }) {
  return (
    <header className="flex items-center justify-between gap-3 px-4 pt-4 pb-3">
      <Clock />
      {children}
    </header>
  );
}
