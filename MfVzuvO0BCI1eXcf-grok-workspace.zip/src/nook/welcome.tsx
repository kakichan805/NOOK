import { useState, type FormEvent } from "react";
import { AppHeader } from "./clock";
import { ROOM_ALT, ROOM_ART } from "./art";
import { cleanName, makeRoom, normalizeRoom } from "./model";

interface WelcomeProps {
  invitedRoom: string;
  savedName: string;
  onJoin: (name: string, room: string) => void;
}

export function Welcome({ invitedRoom, savedName, onJoin }: WelcomeProps) {
  const [name, setName] = useState(savedName);
  const [code, setCode] = useState(invitedRoom);
  const [error, setError] = useState("");

  function submit(event: FormEvent) {
    event.preventDefault();
    const nextName = cleanName(name);
    if (!nextName) {
      setError("Add a name first.");
      return;
    }
    const typed = code.trim();
    const room = typed ? normalizeRoom(typed) : makeRoom();
    if (!room) {
      setError("Use letters, numbers, and dashes only.");
      return;
    }
    setError("");
    onJoin(nextName, room);
  }

  return (
    <div className="mx-auto flex h-dvh w-full max-w-md flex-col bg-lane">
      <AppHeader />
      <main className="flex min-h-0 flex-1 flex-col gap-5 overflow-y-auto px-4 pb-8">
        <figure className="overflow-hidden rounded-room shadow-md">
          <img src={ROOM_ART.study} alt={ROOM_ALT.study} className="h-56 w-full object-cover" />
        </figure>
        <div>
          <h1 className="font-pixel text-4xl leading-none text-paper">Nook</h1>
          <p className="mt-3 text-base leading-relaxed text-muted">
            A shared study room. Put your name in, then move between the desks, the snack table, the bed, the
            washroom, and the door. Anyone with the link can sit with you.
          </p>
        </div>
        <form onSubmit={submit} className="flex flex-col gap-3">
          <label className="flex flex-col gap-2">
            <span className="font-pixel text-xs text-lamp">Your name</span>
            <input
              value={name}
              onChange={(event) => setName(event.target.value)}
              maxLength={16}
              autoComplete="nickname"
              enterKeyHint="done"
              placeholder="Maya"
              className="h-12 rounded-xl bg-paper px-4 text-base text-ink outline-none placeholder:text-muted focus-visible:ring-2 focus-visible:ring-lamp"
            />
          </label>
          <label className="flex flex-col gap-2">
            <span className="font-pixel text-xs text-lamp">Room code</span>
            <input
              value={code}
              onChange={(event) => setCode(event.target.value)}
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck={false}
              placeholder="Leave blank to open a new room"
              className="h-12 rounded-xl bg-ink px-4 text-base text-paper outline-none placeholder:text-muted focus-visible:ring-2 focus-visible:ring-lamp"
            />
          </label>
          {error ? <p className="text-sm text-lamp">{error}</p> : null}
          <button
            type="submit"
            className="h-12 rounded-xl bg-lamp text-base font-bold text-ink focus-visible:ring-2 focus-visible:ring-paper"
          >
            Enter
          </button>
        </form>
      </main>
    </div>
  );
}
