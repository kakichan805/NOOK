import { o as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as DoorOpen, i as Droplets, n as Share2, o as Coffee, r as Moon, s as BookOpen } from "../_libs/lucide-react.mjs";
import { a as formatStay, c as normalizeRoom, d as rememberLeave, f as rememberSpot, i as cleanName, l as readBoot, m as previewPathPrefix, n as Route$1, o as isPresence, p as zoneMeta, r as ZONES, s as makeRoom, u as rememberJoin } from "./router-CxPZSYNc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DwBPm1ZO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Clock() {
	const [now, setNow] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const tick = () => setNow(/* @__PURE__ */ new Date());
		tick();
		const id = window.setInterval(tick, 1e3);
		return () => window.clearInterval(id);
	}, []);
	const time = now ? now.toLocaleTimeString(void 0, {
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit",
		hour12: false
	}) : "--:--:--";
	const day = now ? now.toLocaleDateString(void 0, {
		weekday: "short",
		month: "short",
		day: "numeric"
	}) : "Local time";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", {
			dateTime: now ? now.toISOString() : void 0,
			"aria-label": `Local time ${time}`,
			className: "font-pixel block text-3xl leading-none tracking-wide text-lamp",
			children: time
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-pixel mt-1 text-xs leading-none text-muted",
			children: day
		})]
	});
}
function AppHeader({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex items-center justify-between gap-3 px-4 pt-4 pb-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, {}), children]
	});
}
var study_default = "/assets/study-iQsHnk3R.jpg";
var snack_default = "/assets/snack-BZMPeSuw.jpg";
var rest_default = "/assets/rest-Djm7azJ7.jpg";
var wash_default = "/assets/wash-C_VQI0eg.jpg";
var door_default = "/assets/door-BLdWhObE.jpg";
var look_0_default = "/assets/look-0-rd-OcPN9.png";
var look_1_default = "/assets/look-1-CevKnswH.png";
var look_2_default = "/assets/look-2-84uBwuX-.png";
var look_3_default = "/assets/look-3-B3fmNcSi.png";
var sit_0_default = "/assets/sit-0-ByI2_7M_.png";
var ROOM_ART = {
	study: study_default,
	snack: snack_default,
	rest: rest_default,
	wash: wash_default,
	door: door_default
};
var ROOM_ALT = {
	study: "A cozy study with two wooden desks and warm lamps",
	snack: "A small snack table with tea, fruit, and cookies",
	rest: "A low bed with soft linen and a bedside lamp",
	wash: "A bright washroom with a round mirror and sink",
	door: "The front door, slightly open"
};
var STANDING = [
	look_0_default,
	look_1_default,
	look_2_default,
	look_3_default
];
var STUDYING = [
	sit_0_default,
	look_1_default,
	look_2_default,
	look_3_default
];
function spriteFor(look, zone) {
	const index = (Math.floor(look) % 4 + 4) % 4;
	if (zone === "study") return STUDYING[index];
	return STANDING[index];
}
function Welcome({ invitedRoom, savedName, onJoin }) {
	const [name, setName] = (0, import_react.useState)(savedName);
	const [code, setCode] = (0, import_react.useState)(invitedRoom);
	const [error, setError] = (0, import_react.useState)("");
	function submit(event) {
		event.preventDefault();
		const nextName = cleanName(name);
		if (!nextName) {
			setError("Add a name first.");
			return;
		}
		const typed = code.trim();
		const room = typed ? normalizeRoom(typed) : makeRoom();
		if (!room) {
			setError("Use letters, numbers, and dashes only.");
			return;
		}
		setError("");
		onJoin(nextName, room);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex h-dvh w-full max-w-md flex-col bg-lane",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "flex min-h-0 flex-1 flex-col gap-5 overflow-y-auto px-4 pb-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
					className: "overflow-hidden rounded-room shadow-md",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: ROOM_ART.study,
						alt: ROOM_ALT.study,
						className: "h-56 w-full object-cover"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-pixel text-4xl leading-none text-paper",
					children: "Nook"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-base leading-relaxed text-muted",
					children: "A shared study room. Put your name in, then move between the desks, the snack table, the bed, the washroom, and the door. Anyone with the link can sit with you."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submit,
					className: "flex flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex flex-col gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-pixel text-xs text-lamp",
								children: "Your name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: name,
								onChange: (event) => setName(event.target.value),
								maxLength: 16,
								autoComplete: "nickname",
								enterKeyHint: "done",
								placeholder: "Maya",
								className: "h-12 rounded-xl bg-paper px-4 text-base text-ink outline-none placeholder:text-muted focus-visible:ring-2 focus-visible:ring-lamp"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex flex-col gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-pixel text-xs text-lamp",
								children: "Room code"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: code,
								onChange: (event) => setCode(event.target.value),
								autoCapitalize: "none",
								autoCorrect: "off",
								spellCheck: false,
								placeholder: "Leave blank to open a new room",
								className: "h-12 rounded-xl bg-ink px-4 text-base text-paper outline-none placeholder:text-muted focus-visible:ring-2 focus-visible:ring-lamp"
							})]
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-lamp",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "h-12 rounded-xl bg-lamp text-base font-bold text-ink focus-visible:ring-2 focus-visible:ring-paper",
							children: "Enter"
						})
					]
				})
			]
		})]
	});
}
/**
* Full-mesh WebRTC rooms: one RTCPeerConnection per remote peer, signaled
* through /api/rtc (see signaling.server.ts), game data flowing directly
* browser-to-browser afterwards. Client-authoritative by construction — see
* the multiplayer-p2p skill for when NOT to use this.
*
* Negotiation follows the "perfect negotiation" pattern: on a glare (both
* sides offering at once) the polite peer — the lexicographically smaller id —
* rolls back and accepts, so pairs converge without wedging.
*/
/** Path-based previews serve the app under /{port_id}/ — keep signaling on that prefix. */
function rtcPath(query = "") {
	return `${typeof window === "undefined" ? "" : previewPathPrefix(window.location.hostname, window.location.pathname) ?? ""}/api/rtc${query}`;
}
var FAST_POLL_MS = 400;
var IDLE_POLL_MS = 2e3;
var PING_INTERVAL_MS = 2e3;
var STALL_MS = 1e4;
var MAX_RECOVERY_ATTEMPTS = 3;
var SIGNAL_RETRY_DELAYS_MS = [250, 750];
function defaultIceServers() {
	return [{ urls: ["stun:stun.l.google.com:19302", "stun:stun.cloudflare.com:3478"] }];
}
var P2PRoom = class {
	opts;
	peers = /* @__PURE__ */ new Map();
	/** Per-remote-peer signal delivery chains (order-preserving). */
	signalQueues = /* @__PURE__ */ new Map();
	cursor = 0;
	pollTimer = null;
	pingTimer = null;
	closed = false;
	everPolled = false;
	lastPeersFingerprint = "";
	constructor(opts) {
		this.opts = opts;
	}
	/**
	* The first poll IS the join: it registers this peer and returns the
	* roster. A failed first poll (cold DB, offline tab) must not strand the
	* room: the loop and timers start regardless and the next poll retries.
	*/
	async join() {
		try {
			await this.pollOnce();
		} catch {}
		if (this.closed) return;
		this.schedulePoll(this.anyPairConnecting() ? FAST_POLL_MS : IDLE_POLL_MS);
		this.pingTimer = setInterval(() => {
			this.pingAll();
			this.watchdog();
		}, PING_INTERVAL_MS);
	}
	close() {
		this.closed = true;
		if (this.pollTimer) clearTimeout(this.pollTimer);
		if (this.pingTimer) clearInterval(this.pingTimer);
		for (const slot of this.peers.values()) slot.pc.close();
		this.peers.clear();
		fetch(rtcPath(), {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				op: "leave",
				room: this.opts.room,
				peer: this.opts.selfId
			}),
			keepalive: true
		}).catch(() => {});
	}
	/** Send on the unreliable game-state channel (drops stale packets). */
	broadcast(data) {
		const wire = JSON.stringify({
			t: "d",
			d: data
		});
		for (const slot of this.peers.values()) if (slot.state?.readyState === "open") slot.state.send(wire);
	}
	/** Send reliably (ordered) to one peer, or to all when peerId is omitted. */
	send(data, peerId) {
		const wire = JSON.stringify({
			t: "d",
			d: data
		});
		const targets = peerId ? [this.peers.get(peerId)] : [...this.peers.values()];
		for (const slot of targets) if (slot?.reliable?.readyState === "open") slot.reliable.send(wire);
	}
	peerList() {
		return [...this.peers.values()].map((s) => ({ ...s.info }));
	}
	schedulePoll(delay) {
		if (this.closed) return;
		if (this.pollTimer) clearTimeout(this.pollTimer);
		this.pollTimer = setTimeout(() => void this.poll(), delay);
	}
	anyPairConnecting() {
		for (const s of this.peers.values()) {
			if (s.terminal) continue;
			if (s.info.connectionState !== "connected") return true;
		}
		return false;
	}
	async pollOnce() {
		const params = new URLSearchParams({
			room: this.opts.room,
			peer: this.opts.selfId,
			name: this.opts.name ?? "",
			since: String(this.cursor)
		});
		const res = await fetch(rtcPath(`?${params}`));
		if (this.closed) return;
		if (!res.ok) throw new Error(`signaling poll failed: ${res.status}`);
		const body = await res.json();
		if (this.closed) return;
		if (!this.everPolled) {
			this.everPolled = true;
			this.opts.onConnected?.();
		}
		this.reconcileRoster(body.peers);
		const roster = new Set(body.peers.map((p) => p.id));
		for (const sig of body.signals) {
			this.cursor = Math.max(this.cursor, sig.id);
			await this.onSignal(sig.from, sig.kind, sig.payload, roster);
			if (this.closed) return;
		}
	}
	async poll() {
		if (this.closed) return;
		try {
			await this.pollOnce();
		} catch {}
		this.schedulePoll(this.anyPairConnecting() ? FAST_POLL_MS : IDLE_POLL_MS);
	}
	reconcileRoster(peers) {
		const alive = new Set(peers.map((p) => p.id));
		for (const p of peers) {
			if (p.id === this.opts.selfId) continue;
			const existing = this.peers.get(p.id);
			if (existing) existing.info.name = p.name;
			else this.connectTo(p.id, p.name, this.opts.selfId > p.id);
		}
		for (const [id, slot] of this.peers) if (!alive.has(id)) {
			slot.pc.close();
			this.peers.delete(id);
		}
		this.emitPeers();
	}
	connectTo(peerId, name, initiator) {
		if (this.closed) return null;
		const pc = new RTCPeerConnection({ iceServers: this.opts.iceServers ?? defaultIceServers() });
		const slot = {
			pc,
			makingOffer: false,
			ignoreOffer: false,
			pendingCandidates: [],
			lastProgressAt: Date.now(),
			recoveryAttempts: 0,
			info: {
				id: peerId,
				name,
				connectionState: pc.connectionState,
				candidateType: null,
				rttMs: null
			}
		};
		this.peers.set(peerId, slot);
		pc.onicecandidate = (e) => {
			if (e.candidate) this.sendSignal(peerId, "ice", e.candidate.toJSON());
		};
		pc.onconnectionstatechange = () => {
			slot.info.connectionState = pc.connectionState;
			if (pc.connectionState === "connecting" || pc.connectionState === "connected") slot.lastProgressAt = Date.now();
			if (pc.connectionState === "connected") {
				slot.recoveryAttempts = 0;
				slot.terminal = false;
				this.readCandidateType(slot);
			}
			this.emitPeers();
			if (pc.connectionState === "failed") pc.restartIce();
			if (pc.connectionState === "failed" || pc.connectionState === "disconnected") this.schedulePoll(FAST_POLL_MS);
		};
		pc.onnegotiationneeded = async () => {
			try {
				slot.makingOffer = true;
				await pc.setLocalDescription();
				await this.sendSignal(peerId, "offer", pc.localDescription.toJSON());
			} catch {} finally {
				slot.makingOffer = false;
			}
		};
		pc.ondatachannel = (e) => this.attachChannel(slot, e.channel);
		if (initiator) {
			this.attachChannel(slot, pc.createDataChannel("state", {
				ordered: false,
				maxRetransmits: 0
			}));
			this.attachChannel(slot, pc.createDataChannel("reliable", { ordered: true }));
		}
		return slot;
	}
	attachChannel(slot, channel) {
		if (channel.label === "state") slot.state = channel;
		else slot.reliable = channel;
		channel.onopen = () => {
			slot.lastProgressAt = Date.now();
		};
		channel.onmessage = (e) => {
			let msg;
			try {
				msg = JSON.parse(e.data);
			} catch {
				return;
			}
			if (msg.t === "ping") {
				if (slot.state?.readyState === "open") slot.state.send(JSON.stringify({ t: "pong" }));
			} else if (msg.t === "pong") {
				if (slot.pingSentAt) {
					slot.info.rttMs = Math.round(performance.now() - slot.pingSentAt);
					slot.pingSentAt = void 0;
					this.emitPeers();
				}
			} else this.opts.onMessage?.(slot.info.id, msg.d, channel.label === "state" ? "state" : "reliable");
		};
	}
	/** Apply buffered ICE candidates once a remote description is in place. */
	async flushPendingCandidates(slot) {
		while (slot.pendingCandidates.length > 0) {
			const candidate = slot.pendingCandidates.shift();
			try {
				await slot.pc.addIceCandidate(candidate);
			} catch (err) {
				if (!slot.ignoreOffer) console.warn("[p2p] addIceCandidate failed:", err);
			}
			if (this.closed) return;
		}
	}
	async onSignal(from, kind, payload, roster) {
		if (this.closed) return;
		let slot = this.peers.get(from);
		if (!slot) {
			if (!roster.has(from)) return;
			const created = this.connectTo(from, "", false);
			if (!created) return;
			slot = created;
		}
		const polite = this.opts.selfId < from;
		try {
			if (kind === "offer" || kind === "answer") {
				const description = payload;
				const collision = kind === "offer" && (slot.makingOffer || slot.pc.signalingState !== "stable");
				slot.ignoreOffer = !polite && collision;
				if (slot.ignoreOffer) return;
				try {
					await slot.pc.setRemoteDescription(description);
				} catch (err) {
					if (kind !== "offer" || slot.recreatedForOffer) throw err;
					const attempts = slot.recoveryAttempts;
					const name = slot.info.name;
					slot.pc.close();
					this.peers.delete(from);
					const fresh = this.connectTo(from, name, false);
					if (!fresh) return;
					fresh.recoveryAttempts = attempts;
					fresh.recreatedForOffer = true;
					slot = fresh;
					await slot.pc.setRemoteDescription(description);
				}
				if (this.closed) return;
				await this.flushPendingCandidates(slot);
				if (this.closed) return;
				if (kind === "offer") {
					await slot.pc.setLocalDescription();
					if (this.closed) return;
					await this.sendSignal(from, "answer", slot.pc.localDescription.toJSON());
				}
			} else if (kind === "ice") {
				const candidate = payload;
				if (!slot.pc.remoteDescription) {
					slot.pendingCandidates.push(candidate);
					return;
				}
				try {
					await slot.pc.addIceCandidate(candidate);
				} catch (err) {
					if (!slot.ignoreOffer) console.warn("[p2p] addIceCandidate failed:", err);
				}
			}
		} catch {}
	}
	/**
	* Signals are serialized per remote peer (a candidate must never overtake
	* its SDP into the DB) and retried on failure with short backoff.
	*/
	sendSignal(to, kind, payload) {
		const next = (this.signalQueues.get(to) ?? Promise.resolve()).then(() => this.postSignal(to, kind, payload));
		this.signalQueues.set(to, next.catch(() => {}));
		return next;
	}
	async postSignal(to, kind, payload) {
		for (let attempt = 0;; attempt++) {
			if (this.closed) return;
			try {
				const res = await fetch(rtcPath(), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({
						op: "signal",
						room: this.opts.room,
						from: this.opts.selfId,
						to,
						kind,
						payload
					})
				});
				if (res.ok) return;
				throw new Error(`signal POST failed: ${res.status}`);
			} catch (err) {
				if (attempt >= SIGNAL_RETRY_DELAYS_MS.length) {
					console.warn(`[p2p] signal ${kind} to ${to} failed after retries`, err);
					return;
				}
				await new Promise((r) => setTimeout(r, SIGNAL_RETRY_DELAYS_MS[attempt]));
			}
		}
	}
	pingAll() {
		const wire = JSON.stringify({ t: "ping" });
		for (const slot of this.peers.values()) {
			if (slot.state?.readyState !== "open") continue;
			const stale = slot.pingSentAt !== void 0 && performance.now() - slot.pingSentAt > 2 * PING_INTERVAL_MS;
			if (slot.pingSentAt === void 0 || stale) {
				slot.pingSentAt = performance.now();
				slot.state.send(wire);
			}
		}
	}
	/**
	* Stuck-pair recovery, piggybacked on the ping interval. A pair that has
	* made no progress for STALL_MS gets rebuilt by the dialer with a FRESH
	* RTCPeerConnection (new DTLS identity — fixes the suspend/resume
	* fingerprint wedge). After MAX_RECOVERY_ATTEMPTS the pair is terminal:
	* visible to the app as its last connectionState, ignored by fast-poll.
	*/
	watchdog() {
		if (this.closed) return;
		const now = Date.now();
		for (const [peerId, slot] of this.peers) {
			const live = slot.pc.connectionState;
			if (live !== slot.info.connectionState) {
				slot.info.connectionState = live;
				if (live === "connecting" || live === "connected") slot.lastProgressAt = now;
				this.emitPeers();
			}
			if (slot.terminal || live === "connected") continue;
			if (now - slot.lastProgressAt <= STALL_MS) continue;
			if (slot.recoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
				slot.terminal = true;
				this.emitPeers();
				continue;
			}
			slot.recoveryAttempts += 1;
			slot.lastProgressAt = now;
			if (this.opts.selfId > peerId) {
				const { name } = slot.info;
				const attempts = slot.recoveryAttempts;
				slot.pc.close();
				this.peers.delete(peerId);
				const fresh = this.connectTo(peerId, name, true);
				if (fresh) fresh.recoveryAttempts = attempts;
				this.schedulePoll(FAST_POLL_MS);
			}
		}
	}
	async readCandidateType(slot) {
		try {
			const stats = await slot.pc.getStats();
			let selected;
			stats.forEach((s) => {
				if (s.type === "candidate-pair" && s.nominated) selected = s;
			});
			const localId = selected?.localCandidateId;
			if (localId) {
				const local = stats.get(localId);
				slot.info.candidateType = local?.candidateType ?? null;
				this.emitPeers();
			}
		} catch {}
	}
	emitPeers() {
		const list = this.peerList();
		const fingerprint = JSON.stringify(list.map((p) => [
			p.id,
			p.name,
			p.connectionState,
			p.candidateType,
			p.rttMs
		]));
		if (fingerprint === this.lastPeersFingerprint) return;
		this.lastPeersFingerprint = fingerprint;
		this.opts.onPeersChanged?.(list);
	}
};
/**
* React binding for P2PRoom. Identity and room id are captured once on mount,
* so changing room or name means remounting (key the component on them).
*/
function useP2PRoom(options) {
	const [selfId] = (0, import_react.useState)(options.selfId);
	const [room] = (0, import_react.useState)(options.room);
	const [name] = (0, import_react.useState)(options.name);
	const [peers, setPeers] = (0, import_react.useState)([]);
	const [joined, setJoined] = (0, import_react.useState)(false);
	const roomRef = (0, import_react.useRef)(null);
	const listeners = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	(0, import_react.useEffect)(() => {
		const p2p = new P2PRoom({
			room,
			selfId,
			name,
			onPeersChanged: setPeers,
			onMessage: (from, data, channel) => {
				for (const fn of listeners.current) fn(from, data, channel);
			},
			onConnected: () => setJoined(true)
		});
		roomRef.current = p2p;
		p2p.join();
		return () => {
			roomRef.current = null;
			p2p.close();
		};
	}, [
		room,
		selfId,
		name
	]);
	return {
		selfId,
		room,
		peers,
		joined,
		broadcast: (0, import_react.useCallback)((data) => roomRef.current?.broadcast(data), []),
		send: (0, import_react.useCallback)((data, peerId) => roomRef.current?.send(data, peerId), []),
		onMessage: (0, import_react.useCallback)((fn) => {
			listeners.current.add(fn);
			return () => {
				listeners.current.delete(fn);
			};
		}, []),
		close: (0, import_react.useCallback)(() => {
			roomRef.current?.close();
			roomRef.current = null;
		}, [])
	};
}
var ICONS = {
	study: BookOpen,
	snack: Coffee,
	rest: Moon,
	wash: Droplets,
	door: DoorOpen
};
function Room({ room, name, selfId, initialZone, initialSince, onLeave }) {
	const p2p = useP2PRoom({
		room,
		name,
		selfId
	});
	const [zone, setZone] = (0, import_react.useState)(initialZone);
	const [since, setSince] = (0, import_react.useState)(initialSince);
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	const [others, setOthers] = (0, import_react.useState)({});
	const [note, setNote] = (0, import_react.useState)("");
	const [slow, setSlow] = (0, import_react.useState)(false);
	const look = (0, import_react.useMemo)(() => {
		let hash = 0;
		for (const char of name) hash = hash * 31 + char.charCodeAt(0) >>> 0;
		return hash % 4;
	}, [name]);
	const presence = (0, import_react.useMemo)(() => ({
		name,
		zone,
		since,
		look
	}), [
		name,
		zone,
		since,
		look
	]);
	const presenceRef = (0, import_react.useRef)(presence);
	presenceRef.current = presence;
	const greeted = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setNow(Date.now()), 1e3);
		return () => window.clearInterval(id);
	}, []);
	(0, import_react.useEffect)(() => {
		const id = window.setTimeout(() => setSlow(true), 6e3);
		return () => window.clearTimeout(id);
	}, []);
	(0, import_react.useEffect)(() => p2p.onMessage((from, data) => {
		if (!isPresence(data)) return;
		setOthers((current) => ({
			...current,
			[from]: {
				...data,
				name: data.name.slice(0, 16),
				seen: Date.now()
			}
		}));
	}), [p2p.onMessage]);
	(0, import_react.useEffect)(() => {
		p2p.broadcast(presence);
		const id = window.setInterval(() => p2p.broadcast(presenceRef.current), 2e3);
		return () => window.clearInterval(id);
	}, [presence, p2p.broadcast]);
	(0, import_react.useEffect)(() => {
		for (const peer of p2p.peers) if (peer.connectionState === "connected" && !greeted.current.has(peer.id)) {
			greeted.current.add(peer.id);
			p2p.send(presenceRef.current, peer.id);
		}
		const ids = new Set(p2p.peers.map((peer) => peer.id));
		setOthers((current) => {
			let changed = false;
			const next = { ...current };
			for (const id of Object.keys(next)) if (!ids.has(id)) {
				delete next[id];
				greeted.current.delete(id);
				changed = true;
			}
			return changed ? next : current;
		});
	}, [p2p.peers, p2p.send]);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => {
			const cutoff = Date.now() - 1e4;
			setOthers((current) => {
				let changed = false;
				const next = { ...current };
				for (const [id, person] of Object.entries(next)) if (person.seen < cutoff) {
					delete next[id];
					changed = true;
				}
				return changed ? next : current;
			});
		}, 2e3);
		return () => window.clearInterval(id);
	}, []);
	function move(next) {
		if (next === zone) return;
		const at = Date.now();
		setZone(next);
		setSince(at);
		rememberSpot(next, at);
	}
	function leave() {
		p2p.close();
		onLeave();
	}
	async function share() {
		const url = new URL(window.location.href);
		url.searchParams.set("room", room);
		const shareUrl = url.toString();
		try {
			if (navigator.share) {
				await navigator.share({
					title: "Nook",
					text: "Come study in my nook.",
					url: shareUrl
				});
				return;
			}
		} catch {
			return;
		}
		try {
			await navigator.clipboard.writeText(shareUrl);
			setNote("Link copied");
			window.setTimeout(() => setNote(""), 2e3);
		} catch {
			setNote(shareUrl);
		}
	}
	const people = [...Object.entries(others).filter(([, person]) => person.zone === zone).map(([id, person]) => ({
		id,
		...person
	}))];
	people.splice(Math.floor(people.length / 2), 0, {
		id: "self",
		name,
		zone,
		since,
		look,
		seen: now
	});
	const counts = Object.fromEntries(ZONES.map((item) => [item.id, item.id === zone ? 1 : 0]));
	for (const person of Object.values(others)) counts[person.zone] += 1;
	const failed = p2p.peers.filter((peer) => peer.connectionState === "failed").length;
	const doing = zoneMeta(zone).doing;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex h-dvh w-full max-w-md flex-col bg-lane",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => void share(),
				className: "flex h-11 items-center gap-2 rounded-xl bg-ink px-3 text-paper focus-visible:ring-2 focus-visible:ring-lamp",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, {
					className: "size-4",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-pixel text-xs",
					children: note || "Share"
				})]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-3 px-4 pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-pixel text-sm leading-none text-paper",
						children: doing
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 truncate font-sans text-sm text-muted",
						children: room
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-pixel shrink-0 text-xs text-muted",
					children: p2p.joined ? "In the room" : slow ? "Still connecting" : "Connecting"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative min-h-0 flex-1 overflow-hidden",
				"aria-label": doing,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: ROOM_ART[zone],
						alt: ROOM_ALT[zone],
						className: "nook-fade absolute inset-0 h-full w-full object-cover"
					}, zone),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-x-0 bottom-0 flex items-end justify-evenly gap-1 px-2 pb-3",
						children: people.map((person) => {
							const mine = person.id === "self";
							const tall = people.length <= 1 ? "h-44" : people.length <= 3 ? "h-36" : "h-28";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
								className: "flex w-16 flex-col items-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
									className: "mb-1 flex max-w-full flex-col items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-pixel max-w-full truncate rounded-md px-1.5 py-1 text-xs leading-none " + (mine ? "bg-lamp text-ink" : "bg-paper text-ink"),
										children: person.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-pixel rounded-md bg-ink px-1.5 py-1 text-xs leading-none text-lamp",
										children: formatStay(now - person.since)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: spriteFor(person.look, zone),
									alt: "",
									className: `${tall} w-auto max-w-full object-contain ${zone === "study" || zone === "rest" ? "" : "nook-bob"}`
								})]
							}, person.id);
						})
					}),
					zone === "door" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-x-4 top-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: leave,
							className: "h-12 w-full rounded-xl bg-lamp text-base font-bold text-ink focus-visible:ring-2 focus-visible:ring-paper",
							children: "Step outside"
						})
					}) : null
				]
			}),
			failed > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "px-4 py-2 text-center text-sm text-muted",
				children: [failed === 1 ? "One person" : `${failed} people`, " couldn't connect from their network."]
			}) : null,
			!p2p.joined && slow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 pb-2 text-center text-sm text-muted",
				children: "You can still settle in. Friends appear when the link connects."
			}) : null,
			Object.keys(others).length === 0 && p2p.joined ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 py-2 text-center text-sm text-muted",
				children: "Just you for now. Share the link to study together."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "grid grid-cols-5 gap-1 bg-ink px-2 pt-2",
				style: { paddingBottom: "max(0.75rem, env(safe-area-inset-bottom))" },
				"aria-label": "Places in the room",
				children: ZONES.map((item) => {
					const Icon = ICONS[item.id];
					const active = item.id === zone;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-pressed": active,
						onClick: () => move(item.id),
						className: "flex min-h-14 flex-col items-center justify-center gap-1 rounded-xl px-1 " + (active ? "bg-lamp text-ink" : "text-paper"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-pixel text-xs leading-none",
								children: [item.label, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "sr-only",
									children: [
										", ",
										counts[item.id],
										" here"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-sans text-xs leading-none " + (active ? "text-ink" : "text-muted"),
								children: counts[item.id]
							})
						]
					}, item.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "sr-only",
				"aria-live": "polite",
				children: [
					name,
					" has been ",
					doing.toLowerCase(),
					" for ",
					formatStay(now - since),
					"."
				]
			})
		]
	});
}
function Home() {
	const search = Route$1.useSearch();
	const navigate = Route$1.useNavigate();
	const room = search.room ?? "";
	const [boot, setBoot] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setBoot(readBoot(room));
	}, [room]);
	if (!boot) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex h-dvh w-full max-w-md flex-col bg-lane px-4 pt-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-pixel mt-8 text-4xl text-paper",
			children: "Nook"
		})]
	});
	if (!boot.joined) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Welcome, {
		invitedRoom: room,
		savedName: boot.name,
		onJoin: (name, room) => {
			const next = {
				joined: true,
				name,
				room,
				zone: "study",
				since: Date.now(),
				selfId: boot.selfId
			};
			rememberJoin(next);
			setBoot(next);
			navigate({
				to: "/",
				search: { room },
				replace: true
			});
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Room, {
		room: boot.room,
		name: boot.name,
		selfId: boot.selfId,
		initialZone: boot.zone,
		initialSince: boot.since,
		onLeave: () => {
			rememberLeave();
			setBoot(readBoot(room || boot.room));
		}
	}, `${boot.room}:${boot.selfId}`);
}
//#endregion
export { Home as component };
