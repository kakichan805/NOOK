//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bn87SIlO.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/api/rtc"],
		preloads: ["/assets/index-CySuw4fU.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CySuw4fU.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D4abmLkx.js"]
	}
} });
//#endregion
export { tsrStartManifest };
